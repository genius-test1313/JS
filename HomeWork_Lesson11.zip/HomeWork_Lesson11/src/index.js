import _ from 'lodash';
import axios from 'axios';

// Функція для додавання даних до Local Storage
function addToLocalStorage(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
    console.log(`Додано до Local Storage: ${key} = ${JSON.stringify(value)}`);
}

// Використання lodash для створення об'єкта
const user = {
    id: 1,
    name: 'John Doe',
    email: 'john.doe@example.com'
};

// Додаємо користувача до Local Storage
addToLocalStorage('user', user);

// Отримання даних з API за допомогою axios
axios.get('https://jsonplaceholder.typicode.com/posts/1')
    .then(response => {
        console.log('Дані з API:', response.data);
        addToLocalStorage('post', response.data);
    })
    .catch(error => {
        console.error('Помилка при отриманні даних:', error);
    });